def run_soceng(nama):
    return f"""
[+] Simulasi serangan SocEng terhadap {nama}
- Gunakan info publik untuk membangun kredibilitas
- Buat email/DM seolah-olah dari teman/developer
"""